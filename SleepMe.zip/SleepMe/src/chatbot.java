import javax.swing.*;
import java.awt.*;
import java.awt.event.KeyEvent;
import java.awt.event.KeyListener;

public class chatbot extends JFrame implements KeyListener {
    private int chatRecord=1;

    JPanel p = new JPanel();
    JTextArea dialog = new JTextArea(20,50);
    JTextArea input = new JTextArea(1,50);
    JScrollPane scroll = new JScrollPane(dialog,
            JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED,
            JScrollPane.HORIZONTAL_SCROLLBAR_NEVER
            );

    //array within array.
    String [] [] chatbot = {
            //greetings
            {"Hi","hi","Hello","hola","Hola"},
            {"Hi","Hello"},
            //questions greattings
            {"how are you","how r u","how re u"},
            {"great","awesome"},
            //yes
            {"yes"},
            {"yeah","yess","yup!"},
            //no replies
            {"no","nope","nada"},
            {"am here if u need me","why not?","i got all the time in the world"},
            //question
            {"no sleep for me","have not slept in a long time","i have trouble sleeping"},
            {"why do u think you have trouble sleeping ?","do you want to talk about it"},
            //anxeity question
            {"i worry","i think a lot","am scared"},
            {"ur human , you should feel this way","wanna tell me why? "},
            //default
            {"helloooo","(unavailable for talking )"}
    };

    public static  void main (String [] args){
        new chatbot();

    }

    public chatbot(){
        super ("Sleep Me chat-bot");
        setSize(600,400);
        setResizable(false);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);

        dialog.setEditable(false);
        input.addKeyListener(this);

        p.add(scroll);
        p.add(input);
        p.setBackground(new Color(255,200,0));
        add(p);

        setVisible(true);
    }





    @Override
    public void keyTyped(KeyEvent e) {

    }

    @Override
    public void keyPressed(KeyEvent e) {
        if (e.getKeyCode()==KeyEvent.VK_ENTER){
            input.setEditable(false);
            //----grab the quote
            String quote= input.getText();
            input.setText("");
            addText("--->You:\t"+quote);
            quote.trim();
            while (quote.charAt(quote.length()-1)=='!'
                    ||quote.charAt(quote.length()-1)=='.'
                    ||quote.charAt(quote.length()-1)=='?'
                    ){
                quote=quote.substring(0,quote.length()-1);
            }
            quote.trim();
            byte response =0;
            /*
            0:seaching thro for matches
            1:we didnt find anything in chatbot
            2:we did find something in the chatbot
             */
            //-----check for matches
            int j=0; //which group we are checking
            while (response==0){
                if (inArray(quote.toLowerCase(),chatbot[j*2])){
                    response=2;
                    int r=(int)Math.floor(Math.random()*chatbot[j*2].length);
                    addText("\n-->Sleep Me\t"+chatbot[(j*2)+1][r]);
                }

                j++;
                if (j*2==chatbot.length-1 && response==0){
                    response =1;
                }
            }
            //-----default
            if (response==1){
                int r=(int)Math.floor(Math.random()*chatbot[chatbot.length-1].length);
                addText("\n-->Sleep Me\t"+chatbot[chatbot.length-1][r]);
            }

            addText("\n");
        }
    }

    @Override
    public void keyReleased(KeyEvent e) {
        if (e.getKeyCode()==KeyEvent.VK_ENTER){
            input.setEditable(true);
        }
    }

    public void addText(String str){
        dialog.setText(dialog.getText()+str);
    }

    public boolean inArray(String in,String [] str){
        boolean match=false;
        for (int i=0;i<str.length;i++){
            if (str[i].equals(in)){
                match=true;
            }
        }
        return match;
    }
}
